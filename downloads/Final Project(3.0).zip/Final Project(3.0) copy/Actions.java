

/**
 * All the Methods for used in the GUI class.
 * Most of them are specific actions that will be used by the user manually others will be used by the code, however, all of these will be used when the users pushes submit 
 * NOTE ABOUT 40k:
 * All models(expet vehicles) have a statline that comprises of these stats, they are used for all of the dicerolls in the game. 
 * Ballistic Skill(BS) Weapon Skill(WS) Strength(S), Toughness(T),Initiative (I)  Wounds(W), Attacks(A) Save(Sv) 
 * 
 * @author (Griff Wood) 
 * @version (0.9.5)
 */
import java.util.ArrayList;
public class Actions
{

    /**
     * Using the Warhammer 40k wound chart, this calculates the roll needed to wound an enemy model.
     * @param Your weapons strength, and your target's toughness  Also works for Weapon skill to hit
     * @returns The roll needed to wound
     */
    public static int woundCalculator(int str,int t){
        if(str == t){
            return 4;
        }
        else if(str == t - 1){
            return 5;
        }
        else if(str == t - 2 || str == t - 3){
            return 6;
        }
        else if(str == t + 1){
            return 3;
        }
        else if(str < t + 1){
            return 2;
        }
        else{
            return 1;
        }
    }

    /**
     * Calculates the number of wounds based on how many times you hit, and uses the wound table
     * @param The users strength, the users toughenss, and the number of hits
     * @returns The number of succesfull wounds
     */
    public static int numOfWound(int amnt,int str, int t ){
        int numWounds = 0;//Sets wounds to zero

        //Rolls a dice for all the wounds
        if( d6.roll(numWounds) >= woundCalculator(str, t)){
            numWounds++;                              //If the dice is greater than or equal to the return of woundCalculator() it wounds
        }
        return numWounds;

    }

    /**
     * Tests if a shot hits it's target
     * (Does take into account BS higher than 6)
     */
    public static boolean doesHit(int bs){
        boolean doesHit = false;
        int bsScore = 0;
        if(bs > 10)bs = 10;
        if(bs <= 5)bsScore = basicBS(bs);
        else{
            bsScore = 2;
        } 
        if(d6.roll() >= bsScore){
            doesHit = true;

        }
        else if(bs > 5){
            if(d6.roll() >= (Actions.basicBS(bs - 5))){
                doesHit = true;
            }
        }

        return doesHit;
    }

    /**
     * Basic Ballisitic Skill chart,(dosn't take into account BS higher than 5)
     */
    public static int basicBS(int bs){
        switch (bs) {
            case 1:
            return 6;

            case 2:
            return 5;

            case 3:
            return 4;

            case 4:
            return 3;

            case 5: 
            return 2;

            default:
            return 0;
        }
    }

    /**
     * Rolls a dice/executes a standard ranged Attack with the wahrammer 40k rules
     * @param BS, STR, AP, T, Sv, the number of shots, is it twin linked?, Is the weapon a plasma weapon, Is it a grav Weapon
     * @returns The number of successful hit, wounds and causulties. 
     */
    public ArrayList<Integer> rangedAttack(String bSkill, String str, String armorP, String tough, String save, String shotNums, String twin, String plas, String gra){//Ballistic Skill, Strength, Armour Penetration, Tougness, Save, Shot Number
        /*Basic Rules
         * For basic rules on shooting vehicles look at the rangedVsVehicle methood
         * 1. The firing unit rolls to fire it's weapons, this is put into the ballistic skill chart (I.e. Orks have a BS of two that means they would need a roll of 5 or higher to hit)
         * 2. The firing unit rolls to wound it's target, they put their weapons strenght and then there opponets tougness into the to-wound table (Same rules apply to ballistic skill)
         * 3. The defending unit then gets to make an armor save, for each one they make they get to ignore one of the wounds
         * 4. Wounds are then applied to the model and are done as casulties
         * 5. other attributes such as twin-linked weapons, plasma, weapons, or grav weapons apply
         * 
         */

        //Taken from input

        int bs = Integer.parseInt(bSkill);  
        int sStat = Integer.parseInt(str);
        int ap = Integer.parseInt(armorP);
        int tStat = Integer.parseInt(tough);
        int sv = Integer.parseInt(save);
        int shotNum = Integer.parseInt(shotNums);
        boolean twinLinked = Actions.parseBoolean(twin);
        boolean plasma = Actions.parseBoolean(plas);
        boolean grav = Actions.parseBoolean(gra);

        //New variable
        /*
         * Saves the number of successful hits, wounds, saves etc
         */
        int sucHits = 0; 
        int sucWounds = 0 ;
        int sucSaves = 0;
        int casualties = 0; 
        ArrayList<Integer> returns = new ArrayList<Integer>();

        for(int i = 0; i <= shotNum; i++){ //Tests for hits 
            if(d6.roll() >= Actions.basicBS(bs)){
                sucHits++;
            }
            else{
                if(twinLinked){ //Re-rolls failed hits if the weapon twin linked 
                    if(d6.roll() >= Actions.basicBS(bs)){
                        sucHits++;
                    }
                }
            }
        }
        //Grav Weapons wound based on armor save
        if(grav){ 
            for(int i = 0; i <= sucHits; i++){
                if(d6.roll() <= sv){
                    sucWounds++;
                }
            }
        }
        //Caclulates wounds normally
        else{
            for(int i = 0; i <= sucHits; i++){  
                if(d6.roll() <= Actions.woundCalculator(sStat, tStat) ){
                    sucWounds++;
                }
            }
        }
        //If the Armor Penetration is lower than the armor value (Lower values are better, IE Ap 2 > Ap 3)
        if(ap <= sv){
            sucSaves = 0;
        }
        else{ // If they succeed on the armor save they don't take a wound
            for(int i = 0; i < sucWounds; i++){
                if(d6.roll() <= sv){
                    sucSaves++;
                }
            }
        }
        casualties = sucWounds - sucSaves;
        returns.add(sucHits);
        returns.add(sucWounds);
        returns.add(sucSaves);
        returns.add(casualties);
        return returns; 
    } 

    /**
     *  Rolls htd dice to execute a ranged attack against a vehicle 
     *  Otherwise it's the same as rangedAttack
     *  @param BS, STR, Ap, Vehicle Armor( 10+), number of shots, is the weapon twin linked?, Is the weapon Plasma, Is the weapon a grav weapon?
     *  @returns Succesful hits, damages to the vehicle, the result of the damage table, and the explode distance(only used if thed vehicle explodes)
     */
    public ArrayList<Integer> rangedVsVehicle(String bSkill, String str, String armorP, String armor, String shotNums, String twin, String plas, String gra){//Ballistic Skill, Strength, Armour Penetration, Tougness, Save, Shot Number
        /*
         * Follows the same rules as normal shooting (see ranged attack)
         * BUT when you get to wounding the vehicle, roll two dice, add your strenght, and if it matches the value of the armor your hitting then it loses a hull point
         * Roll on the vehicle damage table, the results are as follows: shaken, stunned, weapon destroyed, imobilized, destroyed and explodes!
         */

        //Taken from methood
        int bs = Integer.parseInt(bSkill);  //Parses all of the values
        int sStat = Integer.parseInt(str);
        int ap = Integer.parseInt(armorP);
        int revArmor = Integer.parseInt(armor);
        int shotNum = Integer.parseInt(shotNums);
        boolean twinLinked = Actions.parseBoolean(twin);
        boolean plasma = Actions.parseBoolean(plas);
        boolean grav = Actions.parseBoolean(gra);
        boolean found6 = false; //Looks through the result of hull points to see if one of the hits results in an explosion
        //New variables
        int lastValue = 0; //Finds the last relevant value for hull point lost
        int sucHits = 0; //Saves the number of successful hits, lost hull points, etc
        int hullPoint = 0 ;
        int vDamageResult = 0;
        int explodeDist = 0; 

        ArrayList<Integer> returns = new ArrayList<Integer>(); //Returns the values within here 
        ArrayList<Integer> results = new ArrayList<Integer>();

        for(int i = 0; i <= shotNum; i++){ //Tests for hits 
            if(d6.roll() >= Actions.basicBS(bs)){
                sucHits++;
            }
            else{
                if(twinLinked){ //Re-rolls failed hits if the weapon twin linked 
                    if(d6.roll() >= Actions.basicBS(bs)){
                        sucHits++;
                    }
                }
            }
        }
        for(int i = 0; i <= sucHits; i++){
            if(revArmor == d6.roll() + sStat){
                hullPoint++;
            }
        }
        //If the Armor Penetration is equal to one then it adds one to damage table result
        if(ap == 1){
            vDamageResult++;    
        }
        for(int i = 0; i <= hullPoint; i++){
            results.add(d6.roll() + vDamageResult);

        }
        //Goes through results and checks if any are sixes, if if finds a six and rolls if it explodes
        for(int i = 0; i < 10; i++){
            lastValue = results.get(i);
            if(results.get(i) <= 6){
                explodeDist = d6.roll();
                break;
            }
        }

        returns.add(sucHits);
        returns.add(hullPoint);
        returns.add(lastValue);
        returns.add(explodeDist);
        return returns; 
    }

    /**
     * Goes through a standard melee charage(use ranged vs vehicle for vehicle melee);
     * A stands for Attacker and D stands for defender 
     * Melee combat works differently than ranged in 40k, In melee the two models stats are used agaisnt each other. 
     * (E.G. Weapon skill, which is plugged into a chart (The same as the to wound chart but with WSa and WSb instead of S and T) 
     */
    public ArrayList<Integer> meleeAttack(String WeaponS, String Strength, String Save, String Lead, String dist , String Ini, String Attack, String Tough, String modCount){
        /*Whooo this is a lot of code....
         * Yes, there really is this many rules to one game
         * Basic summary:
         * 1. parses the stats(Stats are given in this format Attacker Stat/Defenders Stat
         * 2. The attacker rolls two dice, if it's greater than or equal to the distance THE charge is successful! The methoods stops otherwise
         * 3. Begin Attack Phase!: Player with higher initative goes first (The attacker gets a plus one bonus on the charge) 
         * 4. The player with the higher initative, rolls a WS roll(For simplicity's sake it's the same as the to wound table but WSa and WSb instead of S and T)
         * 5. For all the sucessful hits they roll on the strenght to wound table 
         * 6. The player then gets to roll an armor save if they succed then the wounds do not count
         * 7. This repeats for the player with lower initative or happens at the same time if initative is equal
         * 8. This ends a "simple" turn, this repeats until one of the below scenarios is met
         * 9. At the end of each turn you check for four scenarios( A has killed all of the oposing models, D has killed all of the opposing models, A has suffered less casulties or D has suffered less casulties)
         * 10. If there are no more models one side wins!(Yay) and they get to consolodate (move) d6 inches
         * 11. If one of the other two requirements have been met, then side with mored casulties must take a leadership test, if they pass, they stay in combat, otherwise they run!
         * 12. Both sides roll a d6 and add their initative, if the higher value is the running models, then they run away , otherwise they are all removed as casulties (Brutal...) 
         * 
         */

        ArrayList<Integer> returns = new ArrayList<Integer>();
        /*
         * Takes and splits the strings into two numbers
         * I.E. "10/10" becomes 10 and 10
         */
        int[] WS= Actions.parseStat(WeaponS);
        int Wsa = WS [0];
        int Wsd = WS [1];
        int[] S = Actions.parseStat(Strength);
        int Sa = S [0];
        int Sd = S [1];
        int[] Sv = Actions.parseStat(Save);
        int Sva = Sv[0];
        int Svd = Sv[1];
        int[] Ld = Actions.parseStat(Lead);
        int Lda = Ld [0];
        int Ldd = Ld [1];
        int[] I = Actions.parseStat(Ini);
        int Ia = I [0];
        int Id = I [1];
        int[] A = Actions.parseStat(Attack);
        int Aa = A[0];
        int Ad = A[1];
        int[] T = Actions.parseStat(Tough);
        int Ta = T[0];
        int Td = T[1];
        int[] models = Actions.parseStat(modCount);
        int ModA = models[0];
        int ModD = models[1];
        int dis = Integer.parseInt(dist);
        int chargeSuccess; //Two values 1 = success 2 = fail done so it can be returned later
        int turns = 0; // The turns it takes for the combat to end
        int deadA = 0; //TOTAL casulties of the attacker
        int deadD = 0; // TOTAL Casulties of the defender
        int AModA = Aa / ModA; //Attacks per model
        int AModD = Ad / ModD;
        int outcome = 0; // 1 = A dies, 2 =  D dies,  3 =  D routes A,  4 = D routes A, 5 = A runs, 6 = D runs
        boolean winner = true;

        if(d6.roll(2) < dis){ //The diceroll needs to be 12
            chargeSuccess = 0; 
        }
        else{
            chargeSuccess = 1;
            int IBoost = 1; //The attacker gets + 1 initiative for the first turn
            while(!winner){
                if(IBoost == 1){
                    Ia++;
                    IBoost--;
                }
                else if(IBoost == 0){
                    Ia--;
                    IBoost--;
                } 
                if(Ia > Id){ //The attacker has higher initiative
                    //Attacker Attacks First
                    int savesD = 0; //Number of attacks
                    int hitsA = Actions.numOfWound(Aa, Wsa, Wsd); //Number of hits
                    int woundsA = Actions.numOfWound(hitsA, Sa, Td); //Number of wounds
                    int casD = 0; //casulties of the attacker THIS TURN
                    for(int i = 0; i <= woundsA; i++){
                        if(d6.roll() >= Svd){ // Rolls saves
                            savesD++;
                        }
                        casD = woundsA - savesD;
                    }
                    //Then defender attacks second
                    int savesA = 0; //Number of attacks
                    int hitsD = Actions.numOfWound(Ad - (casD *(AModD)), Wsd, Wsa); //Number of hits
                    int woundsD = Actions.numOfWound(hitsD, Sd, Ta); //Number of wounds
                    int casA = 0; //casutlties of the attacker THIS TURN
                    for(int i = 0; i <= woundsD; i++){
                        if(d6.roll() >= Sva){
                            savesA++;
                        }
                        casA = woundsD - savesA;
                    }
                    deadA += casA;
                    deadD += casD;
                }
                else if(Ia < Id){//Defender has higher initiative
                    //Then defender attacks first
                    int savesA = 0; //Number of attacks
                    int hitsD = Actions.numOfWound(Ad, Wsd, Wsa); //Number of hits
                    int woundsD = Actions.numOfWound(hitsD, Sd, Ta); //Number of wounds
                    for(int i = 0; i <= woundsD; i++){
                        if(d6.roll() >= Sva){
                            savesA++;
                        }
                    }
                    int casA = woundsD - savesA;
                    //Attacker Attacks second
                    int savesD = 0; //Number of attacks
                    int hitsA = Actions.numOfWound(Aa - ( casA * (AModA)), Wsa, Wsd); //Number of hits
                    int woundsA = Actions.numOfWound(hitsA, Sa, Td); //Number of wounds
                    for(int i = 0; i <= woundsA; i++){
                        if(d6.roll() >= Svd){
                            savesD++;
                        }

                    }
                    int casD = woundsA - savesD;
                    deadA += casA;
                    deadD += casD;
                }
                else{ //Initiative is equal
                    //The attacker attacks at the same time
                    int savesD = 0; //Number of attacks
                    int hitsA = Actions.numOfWound(Aa, Wsa, Wsd); //Number of hits
                    int woundsA = Actions.numOfWound(hitsA, Sa, Td); //Number of wounds
                    int casD = 0; //casulties of the attacker THIS TURN
                    for(int i = 0; i <= woundsA; i++){
                        if(d6.roll() >= Svd){
                            savesD++;
                        }
                        casD = woundsA - savesD;
                    }
                    //The defender attacks at the same time
                    int savesA = 0; //Number of attacks
                    int hitsD = Actions.numOfWound(Ad, Wsd, Wsa); //Number of hits
                    int woundsD = Actions.numOfWound(hitsD, Sd, Ta); //Number of wounds
                    for(int i = 0; i <= woundsD; i++){
                        if(d6.roll() >= Sva){
                            savesA++;
                        }
                    }
                    int casA = woundsD - savesA;
                    ModA -= casA;
                    deadA += casA;
                    deadD += casD;
                }
                turns++;
                if(deadA == ModA){
                    outcome = 1;
                    winner = true;
                }
                else if(deadD == ModD){
                    outcome = 2;
                    winner = true;
                }
                else if(deadA < deadD){
                    if(d6.roll(2) > Ldd){
                        if((d6.roll() + Ia) < d6.roll() + Id){
                            outcome = 3;
                            deadD = ModD;
                            winner = true;
                        }
                        else{
                            outcome = 6;
                            winner = true;
                        }
                    }
                }
                else if(deadD > deadA){
                    if(d6.roll(2) > Lda){
                        if((d6.roll() + Ia) > d6.roll() + Id){
                            outcome = 2;
                            deadA = ModA;
                            winner = true;
                        }
                        else{
                            outcome = 5;
                            winner = true;
                        }
                    }
                }
            }
        }
        returns.add(turns);
        returns.add(outcome);
        returns.add(deadA);
        returns.add(deadD);
        return returns;
    }           

    /**
     * Parses a String for yes or y or true or 1. 
     */
    public static boolean parseBoolean(String boole) 
    {
        String bool = boole.toLowerCase();
        if(bool.equals("yes") || bool.equals("y") || bool.equals("1") || bool.equals("true") || bool.equals("t")){
            return true;
        }
        else
        {
            return false;
        }

    }

    /**
     * Returns a rating of the stat (of a warhammer 40k model) 
     */
    public String judgeStat(int stat){ 
        String eval = "";

        if (stat == 0){
            eval = "Horrible";
        }
        else if (stat <= 2 && stat != 0){
            eval = "Bad";
        }
        else if (stat >= 3 && stat <= 4 ){
            eval = "Average";
        }   
        else if(stat >= 5 && stat <= 6){
            eval = "Good";
        }
        else if(stat >= 6 && stat <= 7){
            eval = "Very Good";
        }
        else if(stat <= 8 && stat <= 10){
            eval = "Amazing"; 
        }
        else{
            eval = "Error";

        }
        return eval;
    }

    /**
     *  judges the cost effectivness of a model
     *  Based off of  7ED Chaos Space Marine being average
     */
    public int judgeCost(int cost, int stat){ // judges the cost effectivness of a model
        int ratio = cost / stat;
        if( ratio < 2){//Based off of  7ED Chaos Space Marine being average
            return 10;
        } 
        if(ratio == 2){ 
            return 7;
        }
        if(ratio < 2 &  ratio >= 3){
            return 4;
        } 
        if(ratio < 3){
            return 1;
        }
        else{
            return 4;
        }   
    }

    /**
     *Splits a string of stats into two numbers has to be in this format ("Stat1/Stat2") 
     */
    public static int [] parseStat(String Stats){ //
        int [] returns = new int[2];
        String [] stats = Stats.split("/");
        returns [0] = Integer.parseInt(stats[0]);
        returns [1] = Integer.parseInt(stats[1]);
        return returns;
    }
}