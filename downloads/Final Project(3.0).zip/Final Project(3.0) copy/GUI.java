import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*; //needed for ImageIcon, JFrame, JPanel, JLabel, etc.
import javax.swing.ImageIcon;
import javax.swing.event.*;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.util.ArrayList;
/**
 *  Class GUI
 *  Creates a graphical user interface skeleton for running methods
 * 
 *  
 * @author Beckwith & Wood
 * @version 3.0.0
 */
public class GUI extends JFrame implements ActionListener
{
    int selectedMethod = 0;

    String[] methodNames;           //to be used in combobox for selections
    Actions methods = new Actions();
    JComboBox<String> methodSelector;  //pull down menu to select method

    ImageIcon factorIcon = new ImageIcon(GUI.class.getResource(""));  //image for JOptionPanes

    //Panels are set up to hold other things and can be placed within the MasterPanel
    JPanel masterPanel;         //panel for all components of the display
    JPanel topPanel;            //this panel holds the buttonPanel and instructionsPanel
    JPanel buttonPanel;         //panel for the submit and quit buttons 
    JPanel instructionsPanel;   //panel for JLabel with instructions to user
    JPanel ioPanel;             //panel to hold both input and report output
    JPanel reportPanel;         //panel for JLabel for reporting on the text analysis

    JButton quitButton, submitButton, colorButton, clearButton;
    JLabel instructions;        //label for instructions to user
    JTextArea report;           //area to show all results of analysis
    JTextField entry1, entry2, entry3, entry4,entry5, entry6, entry7, entry8, entry9, entry10;  //3 user input entry fields
    JScrollPane outputScroll;

    /**
     * GUI constructor
     */
    public GUI(String title)
    {
        masterPanel = (JPanel) this.getContentPane();  //master panel IS the whole window
        masterPanel.setLayout(new BorderLayout());
        /*
         * SET UP BUTTON PANEL:
         */
        //SUBMIT button: user clicks when ready to analyze text
        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);
        submitButton.setActionCommand("submitButton"); 

        //quit button
        quitButton = new JButton("QUIT");
        quitButton.addActionListener(this);
        quitButton.setActionCommand("quitButton");  

        //color button
        colorButton = new JButton("Color");
        colorButton.addActionListener(this);
        colorButton.setActionCommand("colorButton");

        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        clearButton.setActionCommand("clear");

        buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(
                (int)(Math.random() * 256),
                (int)(Math.random() * 256),
                (int)(Math.random() * 256)));

        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         * TO ADD NEW METHODS, PUT THEIR NAMES IN THIS LIST:
         * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         */
        //create methods selector pull-down menu    

        String[] methodsList ={
                "Home", "Stat Explination",  "Ranged Attack", "Ranged vs Vehicle", "Melee Attack", 
                "Competitive Analysis",};  //list of names of methods to show to user

        methodSelector = new JComboBox<String>(methodsList);  //create the pull-down menu object
        methodSelector.setSelectedIndex(0);                 //sets which one is selected by default
        methodSelector.addActionListener(this);             //this means we can react when a different one is selected
        methodSelector.setActionCommand("methodSelector");  //the command we reacdt to

        /*
         * SET UP ALL OTHER PANELS
         */
        //iINSTRUCTIONS PANEL
        instructionsPanel = new JPanel();
        instructionsPanel.setBackground(new Color(
                (int)(Math.random() * 256),
                (int)(Math.random() * 256),
                (int)(Math.random() * 256)));
        instructions = new JLabel("Warhammer 40k");
       String forLater = "Pre-Made Unit selector:";
        //ADD MEEEEEEEEEEE!!!!!
        //Attempt to create a new unit
        //unitSelector1 = new JComboBox<String>();
        //set font and color
        instructions.setForeground(Color.blue);
        Font font = new Font("Impact", Font.BOLD, 14);
        instructions.setFont(font);
        instructionsPanel.add(instructions);   //put the JLabel into the panel

        //top panel holds buttons and instructions
        topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(2,1));
        topPanel.add(buttonPanel);
        topPanel.add(instructionsPanel);

        //Here's where some instructions are and where report will be shown
        //Decided to scrap the instructions, maybe a bad idea but...

        String storyBlock =
            "IN THE GRIM DARKNESS OF THE FAR FUTURE THERE IS ONLY WAR"+
            "\n \n It is the 41st Millennium. For more than a hundred centuries the Emperor of Mankind has sat immobile on the Golden Throne of Earth." + 
            " He is the master of mankind by the will of the gods and master of a million worlds by the might of His inexhaustible armies." +
            " He is a rotting carcass writhing invisibly with power from the Dark Age of Technology." + 
            " He is the Carrion Lord of the vast Imperium of Man for whom a thousand souls are sacrificed every day so that He may never truly die." + 
            " Yet even in His deathless state, the Emperor continues His eternal vigilance. Mighty battlefleets cross the daemon-infested miasma of the Warp," +
            " the only route between distant stars, their way lit by the Astronomican, the psychic manifestation of the Emperor's will." + 
            " Vast armies give battle in His name on uncounted worlds. Greatest amongst His soldiers are the Adeptus Astartes, the Space Marines, bio-engineered super-warriors." + 
            " Their comrades in arms are legion: the Imperial Guard and countless planetary defence forces, the ever-vigilant Inquisition and the Tech-priests of the Adeptus Mechanicus to name only a few." +
            " But for all their multitudes, they are barely enough to hold off the ever-present threat to humanity from aliens, heretics, mutants -- and far, far worse." + 
            " To be a man in such times is to be one amongst untold billions. It is to live in the cruelest and most bloody regime imaginable. These are the tales of those times." +
            " Forget the power of technology and science, for so much has been forgotten, never to be relearned. Forget the promise of progress and understanding, for in the grim dark future there is only war." +
            " There is no peace amongst the stars, only an eternity of carnage and slaughter, and the laughter of thirsting gods."
        ;
        report = new JTextArea("", 30 , 40);  //numbers are size of text area in chars
        report.setForeground(Color.red);
        Font font2 = new Font("Impact", Font.BOLD, 18);
        report.setFont(font2);
        report.setEditable(false);
        report.setLineWrap(true);
        report.setWrapStyleWord(true);
        //add the report to a scroll pane, so if it gets big, it will scroll:
        outputScroll = new JScrollPane(report);
        //add the scroll pane to the overall panel:
        reportPanel = new JPanel();
        reportPanel.add(outputScroll);
        report.setText(storyBlock);
        /*
         * SET UP TEXTFields FOR USER INPUT:
         */
        entry1 = new JTextField("WS", 10);  //5 is the number of characters width
        entry2 = new JTextField("BS", 10);
        entry3 = new JTextField("T", 10);
        entry4 = new JTextField("W", 10);
        entry5 = new JTextField("I", 10);
        entry6 = new JTextField("A", 10);
        entry7 = new JTextField("Ld", 10);
        entry8 = new JTextField("Sv", 10);
        entry9 = new JTextField("S", 10);
        entry10 = new JTextField("Ap", 10);
        //add the menu and three buttons to the button panel:
        buttonPanel.add(methodSelector);  //menu pull-down menu
        buttonPanel.add(submitButton);  
        buttonPanel.add(quitButton);
        buttonPanel.add(colorButton);
        buttonPanel.add(clearButton);
        //make a panel to add entry boxes and report to:
        ioPanel = new JPanel();
        ioPanel.add(entry1);
        ioPanel.add(entry2);
        ioPanel.add(entry3);
        ioPanel.add(entry4);
        ioPanel.add(entry5);
        ioPanel.add(entry6);
        ioPanel.add(entry7);
        ioPanel.add(entry8);
        ioPanel.add(entry9);
        ioPanel.add(entry10);
        ioPanel.add(reportPanel);
        ioPanel.setBackground(Color.BLACK);
        /*
         * Put the two panels into the master panel, i.e. the whole window:
         */
        masterPanel.add(topPanel, BorderLayout.NORTH);
        masterPanel.add(ioPanel, BorderLayout.CENTER);

        /* 
         * Wrap-up: set title and size of window and set to be visible in the JFrame
         */
        this.setTitle(title);    
        this.setSize(800, 650);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        String introBlock = "Basic Summary of Diceless 40k:" +
            "\nWarhammer 40,000 is a tabletop game for two or more players, where you command an army of miniatures representing" +
            "\nthe Imperium of Man or one of it's many enemies. This application provides help with the rules and assitance with" +  
            "\nplaying the game so that you can fight battles in a nightmarish future. (YAYYY!)" +

            "\n\nThe purpose of this application is three-fold:"+
            "\n1.To help to gently introduce players into the extra-ordinarily complicated world of 40k "+
            "\n(Main rulebook is 207 pages! Dosn't include Codexes (Stat profiles), Campaign books or Aditional rules!)"+
            "\n2. To help give a veteran player a basic idea of how a unit will preform at a given task"+
            "\n3. To help when somone forgot dice, can't bring the, or it would be inapropriate to roll large masses of dice (I.E. a library)"+

            "\n\nUnfortunally my UI is by far too clunky to be used in any normal game, as it is much quicker to memorize the rules." +
            "\nEither way, I hope you enjoy my program!" +
            "\n Version 3.0";
        JOptionPane.showMessageDialog(null, introBlock);
    }

    /**
     * Actionperformed: when a button is pressed, this is automatically called:
     */
    public void actionPerformed (ActionEvent e)
    {
        if(e.getActionCommand() == "methodSelector")
        {
            selectedMethod = methodSelector.getSelectedIndex();  //set the course number

            switch(selectedMethod)
            {
                /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                 * TO ADD NEW METHODS, WRITE INSTRUCTIONS HERE:
                 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                 */
                case 0:  //method1: Home
                { 
                    entry1.setText("WS");
                    entry2.setText("BS");
                    entry3.setText("T");
                    entry4.setText("W");
                    entry5.setText("I");
                    entry6.setText("A");
                    entry7.setText("Ld");
                    entry8.setText("Sv");
                    entry9.setText("S");
                    entry10.setText("Ap");

                    report.setText("Welcome to Diceless Warhammer 40k, please choose an option" +
                        "\n \nIN THE GRIM DARKNESS OF THE FAR FUTURE THERE IS ONLY WAR"+
                        "\n \n It is the 41st Millennium. For more than a hundred centuries the Emperor of Mankind has sat immobile on the Golden Throne of Earth." + 
                        " He is the master of mankind by the will of the gods and master of a million worlds by the might of His inexhaustible armies." +
                        " He is a rotting carcass writhing invisibly with power from the Dark Age of Technology." + 
                        " He is the Carrion Lord of the vast Imperium of Man for whom a thousand souls are sacrificed every day so that He may never truly die." + 
                        " Yet even in His deathless state, the Emperor continues His eternal vigilance. Mighty battlefleets cross the daemon-infested miasma of the Warp," +
                        " the only route between distant stars, their way lit by the Astronomican, the psychic manifestation of the Emperor's will." + 
                        " Vast armies give battle in His name on uncounted worlds. Greatest amongst His soldiers are the Adeptus Astartes, the Space Marines, bio-engineered super-warriors." + 
                        " Their comrades in arms are legion: the Imperial Guard and countless planetary defence forces, the ever-vigilant Inquisition and the Tech-priests of the Adeptus Mechanicus to name only a few." +
                        " But for all their multitudes, they are barely enough to hold off the ever-present threat to humanity from aliens, heretics, mutants -- and far, far worse." + 
                        " To be a man in such times is to be one amongst untold billions. It is to live in the cruelest and most bloody regime imaginable. These are the tales of those times." +
                        " Forget the power of technology and science, for so much has been forgotten, never to be relearned. Forget the promise of progress and understanding, for in the grim dark future there is only war." +
                        " There is no peace amongst the stars, only an eternity of carnage and slaughter, and the laughter of thirsting gods."
                    );
                }
                break;
                case 1:  //method2: Statline Explilantion 
                {
                    entry1.setText("WS");
                    entry2.setText("BS");
                    entry3.setText("T");
                    entry4.setText("W");
                    entry5.setText("I");
                    entry6.setText("A");
                    entry7.setText("Ld");
                    entry8.setText("Sv");
                    entry9.setText("S");
                    entry10.setText("Ap");
                    report.setText("Enter the full statline of a single unit, you will get an explination of what each stat means");
                }
                break;
                case 2:  //method3: Ranged Standard
                {
                    entry1.setText("Firing Bs");
                    entry2.setText("Weapon's S");
                    entry3.setText("Weapons Ap");
                    entry4.setText("Number of Shots");
                    entry5.setText("Target's T");
                    entry6.setText("Target's Sv");
                    entry7.setText("Twin Linked?");
                    entry8.setText("Plasma?");
                    entry9.setText("Grav?");
                    entry10.setText("");
                    report.setText("Enter the firing unit's Balistic Skill (BS), Weapon Strength(S) Armor Penetration (Ap) and Number of Shots, and the defending Unit's toughness (T), and  Armor(Sv)"); 

                }
                break;
                case 3: 
                {//method4: Ranged VS Vehicle 
                    entry1.setText("Firing Bs");
                    entry2.setText("Weapon's S");
                    entry3.setText("Weapon's Ap");
                    entry4.setText("Number of Shots");
                    entry5.setText("Relevant Armor");
                    entry6.setText("Twin Linked?");
                    entry7.setText("Melta?");
                    entry8.setText("");
                    entry9.setText("");
                    entry10.setText("");
                    report.setText("Enter the firing unit's Balistic Skill (BS), Weapon Strength(S) Armor Penetration (Ap) and Number of Shots, and the defending Unit's toughness (T), and  Armor(Sv)");
                }
                break;   

                case 4:
                {
                    entry1.setText("Weapon Skill");
                    entry2.setText("Strength");
                    entry3.setText("Armor Save");
                    entry4.setText("Leadership");
                    entry5.setText("Model distance");
                    entry6.setText("Initative");
                    entry7.setText("Attack Num");
                    entry8.setText("Tougness");
                    entry9.setText("Unit count");
                    report.setText("Enter the stat for both units in one bar, in this format, Attacker's Stat/ Defender's stat. (I.E. Attack stat: 2/1). Don't do this for the distance between the models");
                }
                break;
                case 5:
                {
                    entry1.setText("WS");
                    entry2.setText("BS");
                    entry3.setText("T");
                    entry4.setText("W");
                    entry5.setText("I");
                    entry6.setText("A");
                    entry7.setText("Ld");
                    entry8.setText("Sv");
                    entry9.setText("S");
                    entry10.setText("Cost");
                    report.setText("Enter the full statline of a single unit, and you will get a competitive analysis of that unit");
                }
                break;
                case 6:
                {

                }
                break;
                case 7:
                {

                }
                break;
                case 8:
                {

                }
                break;
                case 9:
                {

                }
                break;
                case 10:
                {

                }
                break;
                case 11:
                {

                }
                break;
                case 12:
                {

                }
                break;
                case 13:
                {

                }
                break;
                default:
                break;
            }
        }
        //SUBMIT BUTTON CLICKED:

        else if(e.getActionCommand().equals("submitButton"))
        {
            //GET ALL ANSWERS FROM USER: GETTEXT() CAN ONLY RETURN STRINGS, SO CONVERT LATER:

            String arg1 = entry1.getText();
            String arg2 = entry2.getText();
            String arg3 = entry3.getText();
            String arg4 = entry4.getText();
            String arg5 = entry5.getText();
            String arg6 = entry6.getText();
            String arg7 = entry7.getText();
            String arg8 = entry8.getText();
            String arg9 = entry9.getText();
            String arg10 = entry10.getText();
            //String resultString; //use this for return values that are Strings
            //int resultInt;       //use this for return values that are integers
            //boolean resultBool;  //use this for return values that are booleans

            switch(selectedMethod)
            {
                /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                 * TO ADD NEW METHODS, CALL THE METHOD HERE, GET THE RESULTS, AND SET THE TEXT OF THE REPORT
                 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                 */
                case 0:  //method1: Explains the basics of what the rules mean
                {
                    //call the method, sending arguments, and store the return value into a String (you don't really need this comment)

                }
                break;
                case 1:  //method2: TESTING
                {
                    if(arg1 == "WS" || arg2 == "BS" || arg3 == "T" || arg4 == "W"|| arg5 == "I" || arg6 == "A" || arg7 == "Ld" || arg8 == "Sv" ){
                        report.setText("You haven't given the proper input for a given stat");
                    } 
                    //set the display to show/explain the results
                    else{
                        report.setText("Greetings, according to your input, Your model has Melee skill of " + arg1 + " and a ranged skill of " + arg2 + ", a toughness of " + arg3 +
                            ", It can take a total of " + arg4 + " succesful shots before it is removed from the game. It's initiative is " + arg5 + " and it gets " + arg6 + 
                            " melee attack(s). To not flee from combat it has to get lower than a " + arg7 + " on the roll of two dice. If it takes a wound, it can make an armor save," +
                            " if it rolls higher than a "  + arg8 + " it dosn't take a wound. It has the base Strength of " + arg9 + ", and it penetrates the armor of all units with armor value " +
                            "lower than " + arg10 + ".");
                        if(arg1 == "4" && arg2 == "4" && arg3 == "4" && arg8 == "3" && (arg7 == "10" || arg7 == "8" || arg7 == "9" )){
                            report.setText("Greetings, according to your input, Your model has Melee skill of " + arg1 + " and a ranged skill of " + arg2 + ", a toughness of " + arg3 +
                                ", It can take a total of " + arg4 + " succesful shots before it is removed from the game. It's initiative is " + arg5 + " and it gets " + arg6 + 
                                " melee attack(s). To not flee from combat it has to get lower than a " + arg7 + " on the roll of two dice. If it takes a wound, it can make an armor save," +
                                " if it rolls higher than a "  + arg8 + " it dosn't take a wound. It has the base Strength of " + arg9 + ", and it penetrates the armor of all units with armor value " +
                                "lower than " + arg10 + "." + "According to you Input, you model is most likely a Space marine of some sort" );
                        }
                        if(arg1 == "3" && arg2 == "3" && arg3 == "3"){
                            report.setText("Greetings, according to your input, Your model has Melee skill of " + arg1 + " and a ranged skill of " + arg2 + ", a toughness of " + arg3 +
                                ", It can take a total of " + arg4 + " succesful shots before it is removed from the game. It's initiative is " + arg5 + " and it gets " + arg6 + 
                                " melee attack(s). To not flee from combat it has to get lower than a " + arg7 + " on the roll of two dice. If it takes a wound, it can make an armor save," +
                                " if it rolls higher than a "  + arg8 + " it dosn't take a wound. It has the base Strength of " + arg9 + ", and it penetrates the armor of all units with armor value " +
                                "lower than " + arg10 + "." + "According to you Input, you model is most likely a Human of some sort" );
                        }
                    }
                }
                break;
                case 2:
                {
                    ArrayList<Integer> data = new ArrayList<Integer>();
                    data = methods.rangedAttack(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9); // Copies the result to an arraylist
                    report.setText("The firing unit hit " + data.get(0) + " times. It wounded " + data.get(1) + " times. The defending unit made " + 
                        data.get(2) + " armour saves. There was a total of " + data.get(3) + " models removed from the game.");
                }
                break;
                case 3://Extension
                {
                    ArrayList<Integer> data = new ArrayList<Integer>();
                    data = methods.rangedVsVehicle(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);

                    switch(data.get(3)){

                        case(1):
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. "
                            + "This means that the vehicle is shaken");
                        break; 
                        case(2):
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. "
                            + "This means that the vehicle is stunned");
                        break;
                        case(3):
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. "
                            + "This means that the weapon " + data.get(3) + " was destroyed");
                        case(4):
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. "
                            + "This means that the vehicle was imobilized");
                        case(5):
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. "
                            + "This mean the vehicle was destroyed");
                        default:
                        report.setText("The firing unit hit " + data.get(0) + " times. Made against vehicle armor " + arg5 + ", it caused a total loss of " + data.get(1) + " hull points. It rolled a " + data.get(2) + " on the vehicle damage table. " +
                            "it exploded a distance of " + data.get(3) + " inches" );
                        break; 

                    }
                }
                break;
                case 4:
                {
                    ArrayList<Integer> returns = new ArrayList<Integer>();
                    returns = methods.meleeAttack(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
                    switch(returns.get(0)){
                        case 0:
                        report.setText("The attacker failed to charge.");
                        break;
                        case 1:
                        report.setText("The attacker suffered full casulties (" + returns.get(2) + ") in " + returns.get(1) + 
                            " turns. The defender suffered " + returns.get(3) + ".");
                        break;
                        case 2:
                        report.setText("The attacker suffered " + returns.get(2) + " casulties in " + returns.get(1) + 
                            " turns. The defender suffered full casulties ( " + returns.get(3) + " ).");
                        break;
                        case 3:
                        report.setText("The defender routed the Attacker in " + returns.get(1) + " turns. The Attacker lost all models(" + returns.get(2) + 
                            "). The defender lost " + returns.get(3) + " models.");
                        break;
                        case 4:
                        report.setText("The attacker routed the defender in" + returns.get(1) + " turns. The attacker lost " + returns.get(2) + 
                            " models. The defender lost all models(" + returns.get(3) + " models."); 
                        break;
                        case 5:
                        report.setText("The attacker ran away in " + returns.get(1) + " turns. The attacker lost " + returns.get(2) +
                            " models. The defender lost " + returns.get(3) + " models."); 
                        break;
                        case 6:
                        report.setText("The defender ran away in " + returns.get(2) + " turns. The attacker lost " + returns.get(2) +
                            " models. The defender lost " + returns.get(3) + "models.");
                        break;

                    }
                }   
                break;
                case 5: 
                {
                    report.setText(methods.evalUnit(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10));
                }
                break;
                case 6:
                {

                }
                break;
                case 7:
                {

                }
                break;
                case 8:
                {

                }
                break;
                case 9:
                {

                }
                break;
                case 10:
                {

                }
                break;
                case 11:
                {

                }
                break;
                case 12:
                {

                }
                break;
                case 13:
                {

                }
                break;
                default:
                break;
            }
        }

        //QUIT BUTTON CLICKED:
        if(e.getActionCommand().equals("quitButton")) //Displays a quote from the universe upon ending the program 
        {
            int message = d6.roll(2);
            String endMess = ""; //Perhaps the most well named variable yet
            //Coders Note: The Imperium(The goverment in 40k) is basically a Facist Theocracy, I decided to add some quotes from the universe, but they might get weird and milataristic
            // I just wanted to add some fun and atmosphere to my project (Also some of the quotes are stolen from other real life people) 
            switch(message){
                case 2:
                endMess = "The first rule of unarmed combat is: don't be unarmed.";
                break;
                case 3:
                endMess = "Hope is the first step on the road to disapointment.";
                break;
                case 4:
                endMess = "A good life is one that serves The Emperor's command."; 
                break;
                case 5:
                endMess = "The secrets of the universe are within my grasp. You cannot stop me now.";
                break;
                case 6:
                endMess = "The only good is knowledge and the only evil is ignorance.";
                break;
                case 7:
                endMess = "Knowledge is power, hide it well.";
                break;
                case 8:
                endMess = "There is still time to change history.";
                break;
                case 9:
                endMess = "Life is not measured in years, but in deeds.";
                break;
                case 10:
                endMess = "Never take a gamble you're not prepared to lose.";
                break;
                case 11:
                endMess = "If all else fails: duck. As a defensive stratagem it's unreliable," + "\n but incredibly reassuring for a moment or two.";
                break;
                case 12:
                endMess = "01001101 01100001 01111001 00100000 01111001 01101111 01110101" + 
                "\n01110010 00100000 01110111 01100101 01100001 01110000 01101111" +
                "\n01101110 00100000 01100010 01100101 00100000 01100111 01110101" +
                "\n01100001 01110010 01100100 01100101 01100100 00100000 01100001" +
                "\n01100111 01100001 01101001 01101110 01110011 01110100 00100000" + 
                "\n01101101 01100001 01101100 01100110 01110101 01101110 01100011" +
                "\n01110100 01101001 01101111 01101110 00101100 00001010 01000001" +
                "\n01110011 00100000 01111001 01101111 01110101 01110010 00100000" +
                "\n01110011 01101111 01110101 01101100 00100000 01101001 01110011" +
                "\n00100000 01100111 01110101 01100001 01110010 01100100 01100101" +
                "\n01100100 00100000 01100110 01110010 01101111 01101101 00100000" +
                "\n01101001 01101101 01110000 01110101 01110010 01101001 01110100" +
                "\n01111001 00101110 00001010 01010100 01101000 01100101 00100000" +
                "\n01001101 01100001 01100011 01101000 01101001 01101110 01100101" +
                "\n00100000 01000111 01101111 01100100 00100000 01110111 01100001" +
                "\n01110100 01100011 01101000 01100101 01110011 00100000 01101111" +
                "\n01110110 01100101 01110010 00100000 01111001 01101111 01110101" +
                "\n00101110 00001010 01010101 01101110 01101100 01100101 01100001" +
                "\n01110011 01101000 00100000 01110100 01101000 01100101 00100000" +
                "\n01110111 01100101 01100001 01110000 01101111 01101110 01110011" +
                "\n00100000 01101111 01100110 00100000 01110111 01100001 01110010" +
                "\n00101110 00001010 01010101 01101110 01101100 01100101 01100001" +
                "\n01110011 01101000 00100000 01110100 01101000 01100101 00100000" +
                "\n01000100 01100101 01100001 01110100 01101000 01100100 01100101" +
                "\n01100001 01101100 01100101 01110010";
                break;

            }
            JOptionPane.showMessageDialog(null, endMess, "Until we meet again...",
                JOptionPane.PLAIN_MESSAGE, factorIcon);    
            System.exit(0);
        }
        else if(e.getActionCommand().equals("colorButton"))
        {
            buttonPanel.setBackground(new Color(
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256))
            );
            instructionsPanel.setBackground(new Color(
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256)));
            ioPanel.setBackground(new Color(
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256),
                    (int)(Math.random() * 256)));
        }
        else if(e.getActionCommand().equals("clear"))
        {
            entry1.setText("");
            entry2.setText("");
            entry3.setText("");
            entry4.setText("");
            entry5.setText("");
            entry6.setText("");
            entry7.setText("");
            entry8.setText("");
            entry9.setText("");
            entry10.setText("");
        }
        //YOU COULD ALSO MAKE A "CLEAR" BUTTON.  WHEN CLICKED, IT WOULD CLEAR THE REPORT AND/OR ENTERED TEXT
        //  LOOK EVERYWHERE THERE WAS A SUBMIT BUTTON, COPY AND PASTE TO DO THE SAME WITH A CLEAR BUTTON

    }

}
/*
 * 01010100 01101000 01100101 00100000 01100010 01101001 
 * 01101110 01100001 01110010 01111001 00100000 01110000 
 * 01101000 01110010 01100001 01110011 01100101 01110011 
 * 00100000 01100001 01110010 01100101 00100000 01110010 
 * 01100101 01100110 01100101 01110010 01100101 01101110 
 * 01100011 01100101 00100000 01110100 01101111 00100000 
 * 01100001 00100000 01110100 01101000 01100101 00100000 
 * 01110100 01100101 01100011 01101000 00101101 01110000 
 * 01110010 01101001 01100101 01110011 01110100 00100000 
 * 01100110 01100001 01100011 01110100 01101001 01101111 
 * 01101110 00100000 01101001 01101110 00100000 00110100 
 * 00110000 01101011 

 */ 