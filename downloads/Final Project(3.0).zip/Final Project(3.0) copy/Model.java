import java.util.ArrayList;
/**
 * Attempt to create a list from the user to choose from
 * 
 * @author (Griff Wood) 
 * @version (1.0)
 */
public class Model
{
    // Stat
    
    private int WS;
    private int BS;
    private int S;
    private int T;
    private int W;
    private int I;
    private int A;
    private int Ld;
    private int Sv;
    private int Ap;
    private int Cost;
    private int ModCount;
    /**
     * 
     */
    public Model(int ws, int bs, int s, int t, int w ,int i, int a ,int ld, int sv, int ap,int cost, int modcount)
    {
        WS = ws;
        BS = bs;
        S = s;
        T = t; 
        W = w; 
        I = i;
        A = a; 
        Ld = ld;
        Sv = sv;
        Ap = ap;
        Cost = cost;
        ModCount = modcount;
    }

    public static ArrayList<Model> preMadeList(){
        ArrayList<Model> models = new ArrayList<Model>();
        //Model SpaceMarine = new Model(4,4,4,4,1,4,1,10,3,5,16);
        //Model Guardsman = new Model(3,3,3,3,1,3,1,8,4,10,6);
        return models;
    }

}
