
/**
 * Creates the GUI for text analysis
 * 
 * When the GUI constructor is called, it will create and display the JFrame 
 * with JPanels in it, allowing for user input and actions like button clicking
 * Basic Summary of the Diceless 40k:
 * Warhammer 40,000 is a tabletop game for two or more players, where you command an army of miniatures representing
 * the Imperium of Man or one of it's many enemies. This application provides help with the rules and assitance with 
 * playing the game so that you can fight battles in a nightmarish future. (YAYYY!)
 * 
 * The purpose of this application is three-fold:
 * 1. To help to gently introduce players into the extra-ordinarily complicated world of 40k 
 * (Main rulebook is 207 pages! Dosn't include Codexes (Stat profiles), Campaign books or Aditional rules!) 
 * 2. To help give a veteran player a basic idea of how a unit will preform at a given task
 * 3. To help when somone forgot dice, can't bring the, or it would be inapropriate to roll large masses of dice (I.E. a library)
 * 
 * Unfortunally my UI is by far too clunky to be used in any normal game, as it is much quicker to memorize the rules.
 * Either way, I hope you enjoy my program!
 * 
 * 
 * WARNING:
 * INCOMING COPYRIGHT BLURB (Better safe than sorry):
 * 
 * This application is completely unofficial and is in no way endorsed by Games Workshop Limited. 
 * Adeptus Astartes, Blood Angels, Bloodquest, Cadian, Catachan, the Chaos devices, Cityfight, 
 * the Chaos logo, Citadel, Citadel Device, Codex, Daemonhunters, Dark Angels, Dark Eldar, 'Eavy Metal,
 * Eldar, Eldar symbol devices, Eye of Terror, Fire Warrior, Forge World, Games Workshop, Games Workshop logo, 
 * Genestealer, Golden Demon, Gorkamorka, Great Unclean One, Inquisitor, the Inquisitor logo, the Inquisitor device,
 * Inquisitor:Conspiracies, Keeper of Secrets, Khorne, Kroot, Lord of Change, Necron, Nurgle, Ork, Ork skull devices,
 * Sisters of Battle, Slaanesh, Space Hulk, Space Marine, Space Marine chapters, Space Marine chapter logos, Tau,
 * the Tau caste designations, Tyranid, Tyrannid, Tzeentch, Ultramarines, Warhammer, Warhammer 40k Device,
 * White Dwarf, the White Dwarf logo, and all associated marks, names, races, race insignia, characters, vehicles,
 * locations, units, illustrations and images from the Warhammer 40,000 universe are either ®, TM and/or © Copyright Games Workshop Ltd 2000-2012,
 * variably registered in the UK and other countries around the world. Used without permission. No challenge to their status intended. All Rights Reserved to their respective owners.
 * 
 * P.S.(I've hidden some quotes from the game in the UI and in the code) 
 * @author A.Beckwith & G.Wood
 * @version 3.0.0
 * 
 * 
 */

public class Runner
{
    public static void main(String args[])
    {
        GUI newGame = new GUI("Diceless 40k");
    }
}

/*
 01010100 01101111 01101100 01101100 00100000 01110100
 01101000 01100101 00100000 01000111 01110010 01100101
 01100001 01110100 00100000 01000010 01100101 01101100
 01101100 00100000 01001111 01101110 01100011 01100101
 00100001 00001010 01010000 01110101 01101100 01101100
 00100000 01110100 01101000 01100101 00100000 01001100
 01100101 01110110 01100101 01110010 00100000 01100110
 01101111 01110010 01110111 01100001 01110010 01100100
 00100000 01110100 01101111 00100000 01100101 01101110
 01100111 01100001 01100111 01100101 00100000 01110100
 01101000 01100101 00001010 01010000 01101001 01110011
 01110100 01101111 01101110 00100000 01100001 01101110
 01100100 00100000 01010000 01110101 01101101 01110000
 00101110 00101110 00101110 00001010 01010100 01101111
 01101100 01101100 00100000 01110100 01101000 01100101
 00100000 01000111 01110010 01100101 01100001 01110100
 00100000 01000010 01100101 01101100 01101100 00100000
 01010100 01110111 01101001 01100011 01100101 00100001
 00001010 01010111 01101001 01110100 01101000 00100000
 01110000 01110101 01110011 01101000 00100000 01101111
 01100110 00100000 01000010 01110101 01110100 01110100
 01101111 01101110 00100000 01100110 01101001 01110010
 01100101 00100000 01110100 01101000 01100101 00100000
 01000101 01101110 01100111 01101001 01101110 01100101
 00001010 01000001 01101110 01100100 00100000 01110011
 01110000 01100001 01110010 01101011 00100000 01010100
 01110101 01110010 01100010 01101001 01101110 01100101
 00100000 01101001 01101110 01110100 01101111 00100000
 01101100 01101001 01100110 01100101 00101110 00101110
 00101110 00001010 01010100 01101111 01101100 01101100
 00100000 01110100 01101000 01100101 00100000 01000111
 01110010 01100101 01100001 01110100 00100000 01000010
 01100101 01101100 01101100 00100000 01010100 01101000
 01110010 01101001 01100011 01100101 00100001 00001010
 01010011 01101001 01101110 01100111 00100000 01010000
 01110010 01100001 01101001 01110011 01100101 00100000
 01110100 01101111 00100000 01110100 01101000 01100101
 00001010 01000111 01101111 01100100 00100000 01101111
 01100110 00100000 01000001 01101100 01101100 00100000 
 01001101 01100001 01100011 01101000 01101001 01101110
 01100101 01110011 
  
 01001000 01100001 01110110 01100101 00100000 01100110
 01110101 01101110 

 01000111 01101100 01101111 01110010 01111001 00100000 
 01110100 01101111 00100000 01110100 01101000 01100101 
 00100000 01001111 01101101 01101110 01101001 01110011 
 01101001 01100001 01101000 00100001 
 *  
 */

 
