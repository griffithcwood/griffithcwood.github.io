
/**
 * This the d6 class, it is made to simulate rolling a six sided die (or d6 for short) 
 * 
 * @author (Griff) 
 * @version (2.0.0)
 */
public class d6
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class d6
     */
    public d6()
    {

    }

    /**
     *Rolls a d6
     *@param The number of times to roll the dice
     *@returns the TOTAL of the dice
     */
    public static int roll(int diceNum)
    {
        int total = 0; 
        for(int i = 0; i < diceNum; i++){
            int diceRoll = (int) (Math.random() * (5) +  1);
            total += diceRoll;

        }
        return total;
    }

    /**
     * Rolls a d6
     */
    public static int roll(){
        int diceRoll = (int) (Math.random() * 6 + 1);
        return diceRoll;

    }

}
