import java.awt.*;
import javax.swing.*;

/**
 * Write a description of class Carrot here.
 * 
 * @author (Griff) 
 * @version (a version number or a date)
 */
public class Carrot
{

    int xLoc;
    int yLoc;
    static int squareSize;
    boolean eaten;
    static int GRID_SIZE;
    int healthiness; //Variable for how long it extends the rabbits lifespan ; 
    /**
     * Constructor for objects of class Carrot
     */
    public Carrot()
    {
        healthiness = (int) Math.floor(Math.random() * 100);
        xLoc = (int) (Math.random() * GRID_SIZE);
        yLoc = (int) (Math.random() * GRID_SIZE);
        eaten = false;
    }

    /**
     * Spawns a new carrot
     * 
     * 
     */
    public static Carrot spawnCarrot()
    {
        Carrot yum = new Carrot();
        return yum;
    }
    /**
     * Gets the rabbit variables from window settings
     */
    public static void impCarrotVar(int s, int sqSize)
    {
        GRID_SIZE = s;
        squareSize = sqSize;
    }

    public void draw(Graphics g, int pad)
    {
        g.setColor(Color.ORANGE);   //sets the color to orange

        int x =  (int)(squareSize * xLoc) + pad;  
        int y =  (int)(squareSize * yLoc) + pad;

        //draw the rabbit square:
        g.fillRect(x, y, squareSize, squareSize);  //rectangle with equal w and h is a square located at (x,y)
    }
    /**
     * Spawns new carrots based on GRID_SIZE
     */
    public static void newCrop(int GRID_SIZE){
        for(int harvest = 0; harvest < (GRID_SIZE / 3) ; harvest++){
            RunnerGUI.food.add(Carrot.spawnCarrot());
        }
    }
    /**
     * Tests if the carrot can be eaten
     * @param The carrot and the rabbit
     * @returns A boolean if it can be eaten 
     */
    public static boolean isEdible(Carrot carrot, Rabbit bunny){
        if(bunny.xLoc == carrot.xLoc && bunny.yLoc == carrot.yLoc){
            return true;
        }
        else{
        return false;
        }
    }
}

