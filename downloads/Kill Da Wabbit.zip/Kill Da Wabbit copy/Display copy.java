import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
/**
 * Displays circles blinking on and off that are moved and resized with each click of the screen
 * When a circle goes off the screen, it randomly finds a new location and direction and speed
 * 
 * @author Beckwith & (Griff Wood)
 * @version 1.2.0
 */
public class Display extends JPanel
{

    Rabbit bunny;
    static ArrayList<Rabbit> population;
    ArrayList<Fox> predators;
    ArrayList<Carrot> food;

    int size;  //how big each bunny square is

    Font font = new Font("Verdana", Font.BOLD, 16);  //nice font for display purposes
    /**
     * CONSTRUCTOR
     */
    public Display(Rabbit bunny,int w, int h, int gridSize, ArrayList<Rabbit> pop, ArrayList<Fox> pred, ArrayList<Carrot> yum) 
    {
        this.bunny = bunny;
        size = gridSize;
        setPreferredSize(new Dimension(w, h));  //set size of display 
        population = pop;
        predators = pred;
        food = yum;
    }

    /**
     * Draw text, grid, and rabbit; called in Window class by a timer calling repaint()
     * @param g the graphics object, automatically sent when repaint() is called
     */
    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g); //clear the old drawings

        final int PAD = 20;      //extra space so field isn't right at edges

        //use drawString show any updates or information:
        g.setFont(font);
        g.drawString("Amount of Rabbits: " + population.size(), 650, 15);
        g.drawString("Amount of Foxes: " + predators.size(), 650, 30);

        //go through field, showing rabbit or empty square:

        for(int col = 0; col < size; col++)
        {
            for(int row = 0; row < size; row++)
            {
                //THIS IS WHERE YOU CHECK FOR DRAWINGS OTHER THAN EMPTY SQUARE
                //   SO CHECK HERE FOR OTHER BUNNIES OR CARROTS, OR WHATEAVER

                if(population.size() == 0){
                    Rabbit.newBatch();
                }
                for(int dinner = 0; dinner < RunnerGUI.food.size(); dinner++){
                    if(food.get(dinner).eaten == true){
                        food.remove(dinner);
                    }
                    if(food.size() > 0 && food.get(dinner).xLoc == col && food.get(dinner).yLoc == row) //Carrot!
                    //NO NEED TO SET COLOR, BECAUSE ALL CARROTS ARE ORANGE
                        food.get(dinner).draw(g, PAD);  //draw the Carrot
                    else if(food.size() > 0)  //square
                    {
                        //find location of where to draw Carrot rectangle:
                        int x =  (int)(food.get(dinner).squareSize * col) + PAD;
                        int y =  (int)(food.get(dinner).squareSize * row) + PAD;

                        //draw Carrot rectangle:
                        g.drawRect(x , y, food.get(dinner).squareSize, food.get(dinner).squareSize);
                    }
                }
                for(int pop1 = 0; pop1 < RunnerGUI.predators.size(); pop1++){
                    if(predators.size() > 0 && predators.get(pop1).xLoc == col && predators.get(pop1).yLoc == row) //Fox!
                    //NO NEED TO SET COLOR, BECAUSE ALL FOXES ARE BLACK
                        predators.get(pop1).draw(g, PAD);  //draw the Fox
                    else if(predators.size() > 0)  //square
                    {
                        //find location of where to draw Fox rectangle:
                        int x =  (int)(predators.get(pop1).squareSize * col) + PAD;
                        int y =  (int)(predators.get(pop1).squareSize * row) + PAD;

                        //draw Fox rectangle:
                        g.drawRect(x , y, predators.get(pop1).squareSize, predators.get(pop1).squareSize);
                    }
                }
                for(int pop = 0; pop < population.size() - 1; pop++){
                    if(population.size() > 0){
                        if(population.get(pop).alive == false){
                            population.remove(population.get(pop));
                        }
                        if(population.get(pop).xLoc == col && population.get(pop).yLoc == row) //Rabbit!
                        //NO NEED TO SET COLOR, BECAUSE EACH BUNNY HAS IT'S OWN COLOR
                            population.get(pop).draw(g, PAD);  //draw the bunny
                        else  //square
                        {
                            //set color of squares:
                            g.setColor(Color.GREEN);

                            //find location of where to draw bunny rectangle:
                            int x =  (int)(population.get(pop).squareSize * col) + PAD;
                            int y =  (int)(population.get(pop).squareSize * row) + PAD;

                            //draw bunny rectangle:
                            g.drawRect(x , y, population.get(pop).squareSize, population.get(pop).squareSize);

                        }
                        if(population.get(pop).numMoves == 10){
                            population.get(pop).setBreedable(true);
                        }
                        if(population.get(pop).numMoves == (int) (WindowSettings.GRID_SIZE * 6  )){
                            population.get(pop).kill();
                        }
                    }
                }
            }
        }
    }
}
