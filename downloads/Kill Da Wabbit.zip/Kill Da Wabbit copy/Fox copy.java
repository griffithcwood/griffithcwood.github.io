import java.awt.*;
import javax.swing.*;
/**
 * Write a description of class Fox here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fox
{
    // instance variables - replace the example below with your own
    int xLoc;
    int yLoc;
    int sqSize;
    int agression;
    Color color;
    static int middleX;
    static int middleY;
    static int squareSize;

    /**
     * Constructor for objects of class Fox
     */
    public Fox(int x, int y, int sqSize)
    {
        xLoc = x;
        yLoc = y;
        color = Color.BLACK;
        agression = 0;
    }

    /**
     * Spanws a ox 
     */
    public static void spawnFox()
    {
        Fox foxy = new Fox(middleX, middleY , squareSize);
        RunnerGUI.predators.add(foxy);
    }
    /**
     * Imports the fox variables from window settigns  
     * 
     */
    public static void impFoxVar(int mx, int my, int sqSize){
        middleX = mx;
        middleY = my;
        squareSize = sqSize;
    }

    /**
     * Moves the fox
     */
    public void move()
    {
        int num = (int) Math.floor(Math.random() * 7);

        switch(num){
            case 0:
            yLoc--; 
            break;

            case 1:
            xLoc--;
            break;

            case 2:
            xLoc--;   
            yLoc--;
            break;

            case 3: 
            yLoc++;
            break;

            case 4:
            xLoc++;
            break;

            case 5:
            xLoc++;
            yLoc++;
            break;

            case 6:
            xLoc--;
            yLoc++;
            break;
            case 7:
            xLoc++;
            yLoc--; 
            break;

        }
    }

    public void draw(Graphics g, int pad)
    {
        g.setColor(color);   //sets the color of this rabbit before drawing

        //location of this Rabbit on grid:
        int x =  (int)(squareSize * xLoc) + pad;  
        int y =  (int)(squareSize * yLoc) + pad;

        //draw the rabbit square:
        g.fillRect(x, y, squareSize, squareSize);  //rectangle with equal w and h is a square located at (x,y)
    }
    /**
     * Tests if the bunny is edible
     * @param The bunny and the fox
     * @returns A boolean if the bunny can eat the fox
     */
    public static boolean edible(Fox fox, Rabbit bunny){
        if(fox.xLoc == bunny.xLoc && fox.yLoc == bunny.yLoc){
            return true;
        }
        else{
            return false;
        }
    }
}

