import java.awt.*;
import javax.swing.*;

public class Rabbit
{
    int xLoc;
    int yLoc;
    char symbol;
    int numMoves;
    Color color;
    static int squareSize;
    boolean isMale;
    boolean canBreed;
    boolean alive;
    static int middleX;
    static int middleY;
    boolean superCarrot;
    /**
     * Constructor for objects of class Rabbit
     */
    public Rabbit(int x, int y, Color c,int sqSize, boolean isM)
    {
        color = c;
        xLoc = x;
        yLoc = y;
        numMoves = 0;
        squareSize = sqSize;
        isMale = isM;
        canBreed = false;
        alive = true;
        superCarrot = false;
    }

    /**
     * 
     * Moves the rabbit
     * 
     * 
     * 
     */
    public void move()
    {
        int num = (int) (Math.random() * 8);

        switch(num){
            case 0:
            yLoc--; 
            break;

            case 1:
            xLoc--;
            break;

            case 2:
            xLoc--;   
            yLoc--;
            break;

            case 3: 
            yLoc++;
            break;

            case 4:
            xLoc++;
            break;

            case 5:
            xLoc++;
            yLoc++;
            break;

            case 6:
            xLoc--;
            yLoc++;
            break;
            case 7:
            xLoc++;
            yLoc--; 
            break;

        }
        numMoves++;
    }
    /**
     * Sets The coordinates of the rabbit
     * @param the desired cooridnates
     */
    public void setCoordinate(int x, int y){
        xLoc = x;
        yLoc = y; 
    }
    //TODO: Nothing else needed for the draw method, unless you want to change something
    public void draw(Graphics g, int pad)
    {
        g.setColor(color);   //sets the color of this rabbit before drawing

        //location of this Rabbit on grid:
        int x =  (int)(squareSize * xLoc) + pad;  
        int y =  (int)(squareSize * yLoc) + pad;

        //draw the rabbit square:
        g.fillRect(x, y, squareSize, squareSize);  //rectangle with equal w and h is a square located at (x,y)
    }
    /**
     * Generates a new Rabbit
     * @param Two rabbits
     * @returns The new rabbit
     */
    public static Rabbit genRabbit(Rabbit bun1, Rabbit bun2){
        boolean gender = false;
        Color color; 
        int intSex = (int) (Math.random() * 2) ;
        int intColor = (int) (Math.random() * 2);
        if(intSex == 1){ //chooses a gender
            gender = false;
        }
        else{
            gender = true;
        }
        if(intColor == 1){ //chooses a color from parent colors 
            color = bun1.color;
        }
        else{
            color = bun2.color;
        }

        Rabbit newBun = new Rabbit(bun1.xLoc + 1, bun1.yLoc , color, squareSize, gender);
        return newBun;
    }
    /**
     * @param Two rabbits
     * @Returns if they can breed at the current moment
     */
    public static boolean canBreed(Rabbit bun1, Rabbit bun2){
        if(bun1.canBreed && bun2.canBreed){ //Boolean val for can breed,
            if(bun1.xLoc == bun2.xLoc && bun1.yLoc == bun2.yLoc){
                if((bun1.isMale && !(bun2.isMale) || bun2.isMale && !(bun1.isMale))){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    /**
     * Sets whether or not the rabbit can breed
     */
    public void setBreedable(boolean answer){
        canBreed = answer;
    }
    /**
     * Kills the Rabbit
     */
    public void kill(){
        alive = false;
    }
    /**
     * creates a New batch of rabbits
     */
    public static void newBatch(){
        int colCounter = 0;
        Rabbit bunny;
        int rabbitNum = WindowSettings.GRID_SIZE / 10 + 5;
        for(int i = 0; i < rabbitNum; i++){
            int red = (int) Math.floor(Math.random() * 245);
            int blue = (int) Math.floor(Math.random() * 245);
            int green = (int) Math.floor(Math.random() * 245);
            Color color = new Color(red, blue , green);
            switch(colCounter){
                case 0:
                bunny = new Rabbit(middleX, middleY, color, squareSize, false);
                break;
                case 1:
                bunny = new Rabbit(middleX + i, middleY + i, color,squareSize, true);
                break;
                case 2:
                bunny = new Rabbit(middleX + i, middleY - i, color, squareSize, false);
                break;
                case 3:
                bunny = new Rabbit(middleX - i, middleY + i, color, squareSize, true);
                break;
                default:
                bunny = new Rabbit(middleX, middleY, color, squareSize, false);
                break;
            }
            RunnerGUI.population.add(bunny);
            colCounter++;
            if(colCounter == 4){
                colCounter = 0;
            } 
        }

    }

    /**
     * Sends the variables from window settings into the rabbit class
     */

    public static void impRabbitVar(int mx,int my, int sqSize){
        middleX = mx; 
        middleY = my;
        squareSize = sqSize;
    }
}

