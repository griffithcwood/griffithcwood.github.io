import java.awt.Color;
import java.util.ArrayList;
/**
 * Runner
 * 
 * @author Beckwith
 * @version 0.1
 */
public class RunnerGUI
{
    static ArrayList<Rabbit> population = new ArrayList<Rabbit>();
    static ArrayList<Fox> predators = new ArrayList<Fox>();
    static ArrayList<Carrot> food = new ArrayList<Carrot>();
    public static void main(String[] args)
    {
        population.clear();
        //the JFrame size:
        int windowWidth = 950;
        int windowHeight = 700;

        //the display panel size:
        int displaySize = 600;

        //makes an nxn grid within the 600 x 600 display
        //YOU COULD ASK THE USER WHAT SIZE GRID THEY WANT
        //starting point for bunny

        //size of 1 Bunny or 1 blank square:
        //make five new bunnys at middle:
        WindowSettings ws = new WindowSettings();
        ws.setGridSize(); // Makes square size and grid size asks for user input;
        Rabbit.impRabbitVar(ws.middleX, ws.middleY, ws.squareSize);// takes the variables and ;
        Fox.impFoxVar(ws.middleX, ws.middleY, ws.squareSize);
        Carrot.impCarrotVar(ws.GRID_SIZE, ws.squareSize);
        Rabbit.newBatch();
        Carrot.newCrop(ws.GRID_SIZE);
        //Makes five new rabbits and adds them to the rabbit array
        //make Frame, handing over Rabbit object to it
        Window win = new Window(windowWidth, windowHeight, ws.GRID_SIZE,population, predators, food);//Makes a new window

        //begin animation
        win.startTimer();
    }
}
