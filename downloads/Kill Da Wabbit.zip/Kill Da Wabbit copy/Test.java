 
import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
 * 
 * @author Beckwith
 * @version 1.2.0
 */
public class Display extends JPanel
{

    Human dude, dude1;
    int size;  //how big each dude square is
    int count = 0; // count for how many times the bunnies collided
    Font font = new Font("Verdana", Font.BOLD, 16);  //nice font for display purposes
    /**
     * CONSTRUCTOR
     */
    public Display(ArrayList<Human> population, int w, int h, int gridSize) 
    {
      
 
        size = gridSize;
        setPreferredSize(new Dimension(w, h));  //set size of display       
    }

    /**
     * Draw text, grid, and Human; called in Window class by a timer calling repaint()
     * @param g the graphics object, automatically sent when repaint() is called
     */
    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g); //clear the old drawings

        final int PAD = 20;      //extra space so field isn't right at edges

        //use drawString show any updates or information:
        g.setFont(font);

        //go through field, showing Human or empty square:
        for(int col = 0; col < size; col++)
        {
            for(int row = 0; row < size; row++)
            {
                //THIS IS WHERE YOU CHECK FOR DRAWINGS OTHER THAN EMPTY SQUARE
                //   SO CHECK HERE FOR OTHER BUNNIES OR CARROTS, OR WHATEAVER
                if(dude.xLoc == col && dude.yLoc == row) //Human!
                //NO NEED TO SET COLOR, BECAUSE EACH dude HAS IT'S OWN COLOR
                    dude.draw(g, PAD);  //draw the dude
                else if (dude1.xLoc == col && dude1.yLoc == row) 
                {
                    dude1.draw(g, PAD);  //draw the dude
                }
                else  //square
                {
                    //set color of squares:
                    g.setColor(Color.GREEN);

                    //find location of where to draw dude rectangle:
                    int x =  (int)(dude.squareSize * col) + PAD;
                    int y =  (int)(dude.squareSize * row) + PAD;
                    int a =  (int)(dude1.squareSize * col) + PAD;
                    int b =  (int)(dude1.squareSize * row) + PAD;
                    //draw dude rectangle:
                    g.drawRect(x , y, dude.squareSize, dude.squareSize);
                    g.drawRect(a , b, dude1.squareSize, dude1.squareSize);
                }
                //CHECK FOR COLLISION:
                if  ((dude.xLoc == dude1.xLoc)  && (dude.yLoc == dude1.yLoc))
                {
                    JOptionPane.showMessageDialog(null," COLLISION");

                }
            }
        }
    }
}