import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
/**
 * Provides a window for buttons entry boxes and displaying of grahpics
 * @author Beckwith & (your name here)
 * @version 1.2.0
 */
public class Window extends JFrame implements ActionListener
{
    //THIS ESTABLISHING THE UPDATE/REFRESH RATE!!!!!
    final int TIMER_DELAY = 20;  //YOU COULD ASK THE USER FOR THIS, BUT THEN TAKE OUT final Orignially 200
    Timer t;
    //components and objects:
    JButton button;
    JPanel topPanel, displayPanel;
    JTextField info;
    Display display;
    Rabbit bunny;

    int gridSize;
    //size of window:
    int WIDTH;
    int HEIGHT;
    static ArrayList<Rabbit> population;
    ArrayList<Fox> predators;
    ArrayList<Carrot> food;
    /**
     * Constructor for Window
     */
    public Window(int width, int height, int gridSize, ArrayList<Rabbit> pop, ArrayList<Fox> pred, ArrayList<Carrot> yum)
    {
        //save instance variables:
        predators = pred;
        food = yum;
        WIDTH = width;
        HEIGHT = height;
        population = pop;
        this.gridSize = gridSize;
        this.bunny = bunny;

        //this allows me to place things where I want them (see this.add below)
        this.setLayout(new BorderLayout());

        //make a button for possible future use:
        button = new JButton("Spawn Fox");
        button.addActionListener(this);
        button.setActionCommand("Spawn Fox");

        //panel for buttons and textfields:
        topPanel = new JPanel();
        topPanel.add(button);

        //add a text field for getting stuff from user, if needed
        info = new JTextField(20);
        topPanel.add(info);

        //make a display object that will show board and motion:
        display = new Display(bunny, WIDTH, HEIGHT, gridSize, population, predators, food);

        //add the display to this JFrame:
        this.add(topPanel, BorderLayout.NORTH);
        this.add(display,     BorderLayout.CENTER);

        //final setup
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));  
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
    }

    /**
     * Creates a Timer object and starts timer
     */
    public void startTimer(){
        t = new Timer(TIMER_DELAY ,this); 
        t.setActionCommand("timerFired");
        t.start();
    }

    /**
     * Called automatically when a button is pressed
     * @param e this contains information about the button that was pressed and is send automatically
     */
    public void actionPerformed(ActionEvent e)
    {
        int moveCode;
        if(e.getActionCommand().equals("Spawn Fox"))  //button has been pressed
        {
            Fox.spawnFox(); //Spawns in a fox
        }
        if(e.getActionCommand().equals("timerFired"))  //timer has fired
        {
            updateAll();            //does all motion and checking and logic (see below)
            display.repaint();      //calls paintComponent to redraw everything
        }
    }

    /**
     * Called by the timer.
     * Do all altering of bunnies, etc. here, since this is followed by a repaint of everything
     */
    public void updateAll()
    {
        if(RunnerGUI.population.size() == 0){
                JOptionPane.showMessageDialog(null, "All the rabbits have died, a new batch of rabbits has been delivered");
                Rabbit.newBatch();
            }
        for(int dinner = 0; dinner < food.size(); dinner++){
            if(food.get(dinner).xLoc < 0 || food.get(dinner).xLoc >= gridSize) food.get(dinner).xLoc = gridSize / 2;
            if(food.get(dinner).yLoc < 0 || food.get(dinner).yLoc >= gridSize) food.get(dinner).yLoc = gridSize / 2;
        }
        for(int pop1 = 0; pop1 < predators.size(); pop1++){
            predators.get(pop1).move();
            if(predators.get(pop1).xLoc < 0 || predators.get(pop1).xLoc >= gridSize) predators.get(pop1).xLoc = gridSize / 2;
            if(predators.get(pop1).yLoc < 0 || predators.get(pop1).yLoc >= gridSize) predators.get(pop1).yLoc = gridSize / 2;
        }
        for(int pop = 0; pop < population.size(); pop++){//update location
            population.get(pop).move();  

            //if off edges, recenter:
            if(population.get(pop).xLoc < 0 || population.get(pop).xLoc >= gridSize) population.get(pop).xLoc = gridSize / 2;
            if(population.get(pop).yLoc < 0 || population.get(pop).yLoc >= gridSize) population.get(pop).yLoc = gridSize / 2;
            for(int i = 0; i < population.size(); i++){
                if(Rabbit.canBreed(population.get(pop), population.get(i))){
                    System.out.println(population.size());
                    Rabbit bugs = Rabbit.genRabbit(population.get(pop), population.get(i));
                    population.add(bugs);

                }
                for(int pop1 = 0; pop1 < predators.size(); pop1++){
                    if(Fox.edible(predators.get(pop1), population.get(pop))){
                        population.get(pop).kill();
                    }
                }
                for(int crop = 0; crop < food.size(); crop++){
                    if(Carrot.isEdible(food.get(crop), population.get(pop))){
                        food.get(crop).eaten = true;
                        population.get(pop).numMoves -= food.get(crop).healthiness;
                        if(population.get(pop).numMoves < 10){
                            population.get(pop).numMoves = 10;
                        }
                    }
                }
            }
            /*
             * Events that will occur
             */
           
            if(population.size() > (Math.pow(WindowSettings.GRID_SIZE, 2) / 2)){
                JOptionPane.showMessageDialog(null, "The amount of rabbits has grown out of control");
                JOptionPane.showMessageDialog(null, "Luckily a meteor hits just in time");
                population.clear();
                predators.clear();
                Rabbit.newBatch();
            }
            if(predators.size() > population.size() / 2){
                JOptionPane.showMessageDialog(null, "Due to the intense competition for food, the foxes have died out");
                if( predators.size() >= population.size() / 2) {
                    predators.clear();
                }

            }
        }
    }   //DO ALL OTHER LOGIC HERE: MAYBE CHECKING OTHER BUNNIES OR FOR COLLISION, ETC.
}
