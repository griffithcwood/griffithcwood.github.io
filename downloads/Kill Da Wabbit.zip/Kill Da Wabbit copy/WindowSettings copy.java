import javax.swing.JOptionPane;
/**
 * A class used for the settings and variables for the Windows class
 * 
 * @author (Griff) 
 * @version (2.1)
 */
public class WindowSettings
{
    // instance variables - replace the example below with your own
    static int GRID_SIZE;
    int middleX;
    int middleY;
    int squareSize;
    
    /**
     * Constructor for objects of class WindowSettings
     */
    public WindowSettings()
    {
        
    }

    /**
     * Asks the user for input on the dimensions of the field and then calculates the middle,
     * and the apropriate grid size
     */
    public void setGridSize()
    {
      
       String GRID_SIZES = JOptionPane.showInputDialog(null, "Enter the size of the field");
       GRID_SIZE = Integer.parseInt(GRID_SIZES);
       middleX = GRID_SIZE / 2;
       middleY = GRID_SIZE / 2;
       squareSize = 600 / GRID_SIZE;
    }
}
