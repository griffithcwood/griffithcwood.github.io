#include <stdio.h>
#include <math.h>
int main()
{
  int number;
  printf("\n Please enter a number: ");
  scanf("%d", &number);
  printf("You entered: %d", number);
  return 0;

}
