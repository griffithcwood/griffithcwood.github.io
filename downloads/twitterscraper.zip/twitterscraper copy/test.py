f encode(code):
    byte_array = []
    byte_code = str.encode(code)
    print(type(byte_code))  # ensure it is byte representation
    for byte in byte_code:
        byte = ~byte
        byte << 3
        byte_array.append(byte)
    return byte_array

def decode(byte_array):
    
    code = ""
    for byte in byte_array:
        byte >> 3
        byte =  ~byte
        code = code + bytes.decode(bytes(byte))
       
    return code
word = "test"
print(encode(word))
hello = encode(word)
print(decode(hello))