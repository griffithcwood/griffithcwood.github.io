from twitterscraper import query_tweets
import sys
list_of_tweets = query_tweets("Trump", 20)
def main():
#print the retrieved tweets to the screen:
    for tweet in list_of_tweets:
        print(tweet.text.encode('utf-8'))
    input("Enter anything to exit: ")
    sys.exit(0)
main()