from twitterscraper import query_tweets
import sys
query = input("Enter a keyword to search: ")
num_query = int(input("Enter a number of tweets to search: "))
list_of_tweets = query_tweets(query, num_query)
def main():
    #print the retrieved tweets to the screen:
    for tweet in list_of_tweets:
        print(tweet)

    #Or save the retrieved tweets to file:
    file = open('output','w')
    file.write("Most recent tweets by " + query + ": \n")
    for tweet in list_of_tweets:
        text = str(tweet.text)
        file.write(text + '\n\n')
    file.close()

    input("Enter anything to exit: ")
    sys.exit(0)
main()