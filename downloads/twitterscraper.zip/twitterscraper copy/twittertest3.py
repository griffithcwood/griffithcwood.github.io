from twitterscraper import query as q
import sys
def main():
    person = input("Enter a person: ")
    #enter the name after the @ I.E. for Donald Trump enter realDonaldTrump
    list_of_tweets = q.query_single_page("https://twitter.com/" + person)

    file = open('output','w')
    total = 0
    file.write("Most recent tweets on " + person + ": \n")
    list = list_of_tweets[0]
    for tweet in list:
        print(type(tweet))
        likes = int(tweet.likes)

        total += likes
        text = str(tweet.text + "\ng")
        print(total)
        file.write(text + "\n")

    file.close()

            #print("Coresponding Twitter account could not be found")
    input("Enter anything to exit: ")
    sys.exit(0)
main()